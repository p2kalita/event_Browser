"""
============================================================
  PARTHA'S WORK — core/base_stage.py
  Abstract base for any validation stage.
  Partha defines the contract; Tanisha implements it.
============================================================
"""

from abc import ABC, abstractmethod
from core.event_bus import EventBus, Event


class BaseStage(ABC):
    """
    Any validation stage inherits from this.
    Partha defines the interface:
        - name       : display label
        - critical   : if True, failure aborts the pipeline
        - execute()  : subclass implements domain logic

    Partha does NOT dictate which events get published —
    that's entirely up to the subclass.
    """

    def __init__(self, name: str, critical: bool = False):
        self.name     = name
        self.critical = critical
        self._bus     = EventBus()   # always the singleton

    @abstractmethod
    def execute(self, context: dict) -> bool:
        """
        Run the stage against the given context dict.
        Returns True (passed) or False (failed).
        Subclass is responsible for publishing events.
        """
        ...

    def _publish(self, event_type: str, payload: dict,
                 severity: str = "INFO") -> Event:
        """Convenience wrapper so subclasses don't import EventBus directly."""
        return self._bus.publish(event_type, payload, severity)
